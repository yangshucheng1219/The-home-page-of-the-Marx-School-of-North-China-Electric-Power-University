import React from "react";

class ReduxTest extends React.Component {
  render() {
    return <p>这是一个Redux测试页面</p>;
  }
}

export default ReduxTest;
