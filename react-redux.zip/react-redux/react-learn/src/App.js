//导入需要配置路由的组件
import React from "react";
import ReduxTest from "./redux/redux.js";
import Game from "./Game";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";

// 路由配置说明（你不用加载整个配置，
// 只需加载一个你想要的根路由，
// 也可以延迟加载这个配置）。
function App() {
  return (
    <Router>
      <div>
        <Routes>
          {/* 配置路由 */}
          <Route path="/" element={<Game />} />
          <Route path="/redux" element={<ReduxTest />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
