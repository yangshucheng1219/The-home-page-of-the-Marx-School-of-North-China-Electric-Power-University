import "./index.css";

import React from "react";
// 注意：应该将 组件 的导入放在样式导入后面，从而避免样式覆盖的问题
import App from "./App";
import { createRoot } from "react-dom/client";

const container = document.getElementById("root");
const root = createRoot(container);

root.render(<App />);
